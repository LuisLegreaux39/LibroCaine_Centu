<!DOCTYPE html>
<html lang="en">

<head>
	<?php require_once('Componentes/MetaInfo.html'); ?>
</head>

<body>
	<?php require_once('Componentes/Nav.html'); ?>
	<?php require_once('Componentes/MiddleImage.html'); ?>
	<?php require_once('Componentes/AtYourService.html'); ?>
	<?php require_once('Componentes/AboutSection.html'); ?>
	<?php require_once('Componentes/GetInTouch.html'); ?>
	<?php require_once('Componentes/GetInTouch.html'); ?>
	<?php require_once('Componentes/Footer.html'); ?>

	<?php require('Componentes/jsFiles.html') ?>
</body>

</html>